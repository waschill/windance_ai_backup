param(
    [string]$Assignee = "Vega",
    [string]$Status = "pending",
    [string]$TaskId = "",
    [string]$Result = "",
    [string]$CompletedBy = "Vega",
    [string]$Harness = "http://192.168.36.21:8791"
)

$ErrorActionPreference = "Stop"

function Invoke-HarnessJson {
    param(
        [string]$Method = "GET",
        [string]$Uri,
        [string]$Body = ""
    )
    $args = @("-sS", "--max-time", "30", "-X", $Method, $Uri)
    if ($Body) {
        $args += @("-H", "Content-Type: application/json", "-d", $Body)
    }
    $raw = & curl.exe @args
    if ($LASTEXITCODE -ne 0) {
        throw "curl.exe failed with exit code $LASTEXITCODE"
    }
    if ($raw) {
        $raw | ConvertFrom-Json
    }
}

if ($TaskId -and $Result) {
    $body = @{
        result = $Result
        status = "completed"
        completed_by = $CompletedBy
    } | ConvertTo-Json -Depth 5
    Invoke-HarnessJson -Method "POST" -Uri "$Harness/staff/tasks/$TaskId/complete" -Body $body
    exit
}

if ($TaskId) {
    Invoke-HarnessJson -Uri "$Harness/staff/tasks/$TaskId"
    exit
}

$query = "assignee=$([uri]::EscapeDataString($Assignee))&status=$([uri]::EscapeDataString($Status))&limit=25"
Invoke-HarnessJson -Uri "$Harness/staff/tasks?$query"
