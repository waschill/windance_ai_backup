# Herald Agent Stack

## Current operating model

Herald is the persistent assistant host and normal main point of contact for the Windance AI stack. SAL remains the iMessage and Node-RED gateway. AL keeps the existing services available. HAL remains the local AI/Ollama/Codex machine.

The production assistant path is now the Herald Agent Harness, not the experimental Hermes dashboard chat path.

## Live harness

- Service: `com.windance.agent-harness`
- Host: HERALD / `192.168.36.21`
- Port: `8791`
- Health: `http://192.168.36.21:8791/health`
- Message endpoint: `POST http://192.168.36.21:8791/message`
- Path: `/Users/herald/services/agent-harness/agent_harness.py`
- LaunchAgent: `/Users/herald/Library/LaunchAgents/com.windance.agent-harness.plist`
- Memory/audit database: `/Users/herald/.local/share/agent-harness/harness.db`
- Infrastructure inventory on Herald:
  - `/Users/herald/.config/agent-harness/infrastructure-inventory.yaml`
  - `/Users/herald/knowledge/infrastructure-inventory.yaml`

The old draft Windance harness on port `8890` is not the active assistant route.

## Herald Direct web chat

The public dashboard hostname is also the direct web-chat entry point:

```text
https://herald.reflectsody.com/chat
```

This route is served by the Hermes dashboard origin on port `9120`, so it uses the existing Cloudflare tunnel and the existing dashboard login. The page does not use the experimental Hermes chat engine. It posts to same-origin `POST /api/herald-direct/message`, which proxies to the reliable Herald Agent Harness at `http://127.0.0.1:8791/message`.

Use this from HAL/Windows when iMessage is inconvenient but you want the same reliable backend that Max uses.

Herald Direct now passes recent same-channel conversation context into the Agent Harness. Normal chat includes the last several turns, and phrases such as `what did I just tell you?`, `what was your last response?`, and `repeat that` are routed to recent conversation recall instead of durable memory search.

## Herald General Manager layer

Herald Core now includes the first General Manager operations ledger.

William's approved working profile is installed at `/Users/herald/knowledge/WILLIAM_PROFILE.md`.

- Current version: 1.0
- Memory pointer: `user_profile/william_profile_v1_installed`
- Purpose: communication preferences, decision philosophy, organizational culture, command structure, and safety boundaries for Herald/Max/Vega/Forge.

Herald also has an explicit command structure available through `GET /team` and the chat route `Who is on your team?`:

- William: President/CEO, holder of the master plug
- Shawn: Executive VP, the real Boss; not the AI staff reporting parent
- Herald: VP of Operations, reports to William
  - Vega / Codex: VP of Technology
    - Sentinel: Network Monitor
    - Forge: Herald-local Codex worker / technical task executor
  - Max: Communications Manager
    - Iris: Gmail and Calendar
  - Ledger: Business Manager
  - Scout: Research Manager
  - Archivist: Historian
- Athena: VP of Quality Assurance, reports to William

The roster is also saved as durable memory under `system_identity/herald_operating_team` and vector-indexed for semantic recall.

Herald is the front door/general manager for day-to-day operation. William should be able to message Herald through iMessage, voice, or web chat and have Herald route the work to the right staff member, track the result, and report back.

Vega is Codex in the Windance structure and remains William's live Codex confidant and strategic technical lead for programming, debugging, infrastructure engineering, and implementation. Sentinel and Forge report to Vega for technical execution. In normal daily use, Herald coordinates and Vega/Forge executes technical work behind the scenes.

Forge is the Herald-local Codex worker/task executor. Forge runs on Herald, processes queued staff tasks, and reports results back through the Agent Harness. Forge is not the same live conversational context as Vega.

Athena is Internal Audit meets QA. She does not create, execute, or answer users. Her job is to ask "Is this correct?", review Vega's code, verify Ledger's calculations, fact-check Scout's research, proofread Max's emails, audit Iris before appointments are changed, detect hallucinations, and score confidence. Athena has veto power but no production authority.

Operational transparency:

- William wants to know which part of the AI stack did the actual work so he can understand the system and become a better team player.
- Agent Harness `/message` replies include a concise `How I worked` section showing the route, department, tools used, and whether any changes were made.
- This is an operational trace/work log, not private chain-of-thought.

Agent staffing policy:

- William explicitly allows Codex/Herald to spawn helper agents when they are useful for parallel work, audits, or specialized subtasks.
- Each spawned agent should receive a narrow job description, the minimum context needed, and clear reporting expectations.
- New helper agents are treated as Windance stack "new hires": useful, supervised, and not allowed to wander into risky/destructive work without approval.
- Running joke/operating culture: each new hire receives the equivalent of 10% of Herald's salary, plus one day per month of extra work they may use as they see fit.

Staff dispatch bridge:

- Storage: SQLite table `staff_tasks` in `/Users/herald/.local/share/agent-harness/harness.db`
- Purpose: real work-order delegation between Herald and staff. Herald must not role-play delegation; if a staff member has not posted a result, Herald should say the task is pending.
- Front-door routing: practical requests such as “check/fix/build/setup/test Herald/SAL/Node-RED/the network” should create a real staff task instead of falling through to generic chat. Herald may route Gmail/Calendar work to Iris, Odoo work to Ledger, research to Scout, monitoring/status to Sentinel, and technical implementation/repair to Forge/Vega.
- Routes:
  - `POST /staff/tasks`
  - `GET /staff/tasks?assignee=Forge&status=pending`
  - `GET /staff/tasks/{id}`
  - `POST /staff/tasks/{id}/complete`
- Chat commands:

```text
Max, ask Forge if the external storage for Herald is setup and being used.
staff tasks
Forge task 1234abcd
```

Project creation workflow:

```text
Max, create a project: AI stack cleanup and compaction.
Goal: ...
```

This is deterministic. Herald creates an `ops_items` project, queues a Forge read-only audit task, an Athena QA task, and an Archivist context-preservation task, then returns real IDs. The model must not merely say it will create the project.

- HAL helper for active Codex/Forge staff tasks:

```powershell
.\forge_staff_bridge.ps1
.\forge_staff_bridge.ps1 -TaskId <id>
.\forge_staff_bridge.ps1 -TaskId <id> -Result "answer text"
```

Forge/Codex worker on Herald:

- Codex CLI is installed on HERALD and authenticated with the existing OpenAI API key.
- Runner: `com.windance.forge-runner`
- Script: `/Users/herald/services/forge-runner/forge_task_runner.py`
- Workspace: `/Users/herald/forge-workspace`
- Bootstrap: `/Users/herald/knowledge/FORGE_BOOTSTRAP.md` and `/Users/herald/forge-workspace/AGENTS.md`
- Schedule: launchd runs every 120 seconds and processes one pending Forge task at a time.
- Behavior: `Max, ask Forge ...` creates a durable task. The local runner picks it up, runs `codex exec`, posts the result back to `/staff/tasks/{id}/complete`, and Herald can report the answer with `Forge task <id>`.
- Backward compatibility: `Vega task <id>` still checks a task id, but new delegated local work should be assigned to Forge.

Current limitation: the runner is intentionally probationary. It can process work orders and run Codex locally, but should return a blocked/needs-approval result for risky/destructive changes, SyncThing changes, account mutations, purchases, DNS changes, reboots, or anything requiring broader explicit authority.

- Storage: SQLite tables `ops_items` and `ops_events` in `/Users/herald/.local/share/agent-harness/harness.db`
- Chat commands:

```text
Track Herald General Manager build: We added the first operations ledger.
Where are we on Herald General Manager build?
What is the status of Steel Reflections?
Give me an update on Google Workspace integration.
```

The ledger is intended to become Herald's structured view of active projects, blockers, owners, next actions, and status history. It complements memory rather than replacing it.

Planned memory layers:

- exact structured memory: SQLite facts, rules, preferences, ops ledger;
- episodic memory: conversation log and daily summaries;
- vector memory: semantic recall over memories, conversations, documents, Odoo notes, and web research;
- reflective memory: daily/weekly consolidation into durable decisions and preferences.

Implemented vector memory:

- Storage: SQLite table `vector_memory`
- Embedding model: `text-embedding-3-small`
- Sources indexed: `memory`, `conversation`, `ops_item`
- Endpoints:

```text
GET /memory/vector?q=metal wall art Shawn
POST /memory/vector/reindex?limit=200
```

Implemented reflection:

- Endpoint: `POST /reflection/daily`
- Chat command: `daily reflection`, `reflect on today`, or `review today`
- Output is saved as `daily_reflection/YYYY_MM_DD` and vector-indexed automatically.
- Schedule: launchd runs `/Users/herald/services/agent-harness/daily_reflection.py` every night at 9:30 PM using `com.windance.daily-reflection`.
- Purpose: compress the day's useful conversations, decisions, preferences, tool changes, and open threads into durable searchable memory for the next day.

## Herald power/display behavior

Herald should stay awake as a server while allowing the display to sleep/black out.

- Service: `com.windance.keepawake`
- Command: `/usr/bin/caffeinate -s -m -i`
- Purpose: prevents system sleep and disk idle sleep, but does not prevent display sleep.
- Current display sleep setting remains macOS `displaysleep 10`, so the screen should go black after idle time.
- Wake-on-LAN is enabled in `pmset` as `womp 1`.

## Messaging

SAL Node-RED owns iMessage access because Messages.app is already working there.

- Node-RED: `http://192.168.36.22:1880`
- iMessage send endpoint: `POST /codex/send-imessage`
- Main iMessage front door: tab `05 - Max + iMessage`
- Normal approved iMessage traffic now routes to Herald Agent Harness at `http://192.168.36.21:8791/message`
- Node-RED bridge endpoint `POST /herald/message` also routes to the 8791 harness.
- Node-RED dashboard monitors HERALD in the `Device Status` group using `http://192.168.36.21:8791/health` every 3 minutes.
- Node-RED dashboard monitors HERALD CPU in the `System Metrics` group using `http://192.168.36.21:8791/system/cpu` every 10 seconds.
- HERALD is included in the 7 AM Network Report device list.

## Probation rules

The harness is in probation mode.

During probation, Herald/Max may:

- Read and summarize unread inbox mail.
- Annotate and classify email.
- Store memories and preferences.
- Notify William through iMessage.
- Prepare recommendations.

During probation, Herald/Max must not do these without explicit approval:

- Send email.
- Delete/archive/move mail.
- Change DNS or Cloudflare.
- Reboot machines.
- Modify Node-RED flows.
- Modify services or files.

Permanent standing rule:

- Do not change anything related to SyncThing unless William explicitly asks for a SyncThing change in that turn.

## Model backend

The harness is provider-aware.

- If a valid OpenAI API key is installed in the service environment, it should use OpenAI as the primary reasoning layer.
- If no valid key is present, it falls back to HAL Ollama via `http://192.168.36.10:11434/v1`.

As of 2026-06-29, OpenAI is configured and working as the primary provider using `gpt-4.1-mini`.

Gemini is also configured and tested through Google's OpenAI-compatible endpoint:

- Base URL: `https://generativelanguage.googleapis.com/v1beta/openai`
- Model: `gemini-2.5-flash`
- Role: fallback/secondary provider

HAL Ollama remains the final local fallback.

## Brave Search

Brave Search connector is installed and active in the Herald Agent Harness. The harness now uses two Brave modes:

- normal Web Search for lightweight links/snippets;
- LLM Context for agent-ready source ingestion and grounded answers.

- Status endpoint: `GET http://192.168.36.21:8791/search/status`
- Search endpoint: `POST http://192.168.36.21:8791/search/web`
- Context/ingestion endpoint: `POST http://192.168.36.21:8791/search/context`
- API key environment variable: `BRAVE_SEARCH_API_KEY`
- API endpoint used: `https://api.search.brave.com/res/v1/web/search`
- LLM Context endpoint used: `https://api.search.brave.com/res/v1/llm/context`

The API key lives in `/Users/herald/.hermes/.env`:

```sh
BRAVE_SEARCH_API_KEY=...
```

Then restart/check:

```sh
ssh HERALD 'launchctl kickstart -k gui/$(id -u)/com.windance.agent-harness'
ssh HERALD 'curl -sS http://127.0.0.1:8791/search/status'
```

From iMessage/Max, use:

```text
Max search weather alerts near Rapid City
Max research best fence charger for horses
Max read web current Node-RED release notes
Max ingest latest Cloudflare tunnel docs
```

Use `search` when you want links and snippets. Use `research`, `read web`, or `ingest` when Herald should consume source context and answer from it.

The Agent Harness also auto-routes obvious web intent such as URLs, `look up`, `latest`, `current`, `website`, and `release notes` to web research. If a message combines web intent with memory intent, such as:

```text
Research the company called Steel Reflections and remember what he finds.
```

Herald uses Brave LLM Context, creates a durable `web_research/<topic>` memory record, and then verifies recall through the normal memory path.

## Browser automation

Hermes has the `browser` toolset enabled, and the bundled `browser-browser-use` plugin is enabled on Herald. This is the "agent-browser" path for an agent opening pages and interacting with them.

- Plugin: `browser-browser-use`
- Runtime: `agent-browser`
- Browser binary: Chromium installed under `/Users/herald/.agent-browser/browsers/`
- Service affected: Hermes dashboard / future Hermes sessions
- Auth: `BROWSER_USE_API_KEY` in `/Users/herald/.hermes/.env`
- Last smoke test: `hermes chat --toolsets browser,web` opened `https://example.com` and returned page title `Example Domain`.

Brave Search does not authorize browser automation. It only authorizes web search results. If changing browser backends later, choose one of these authorization paths:

```sh
BROWSER_USE_API_KEY=...
```

or a different browser backend such as Browserbase:

```sh
BROWSERBASE_API_KEY=...
BROWSERBASE_PROJECT_ID=...
```

Local GUI browser automation is also possible, but that is a separate build path and will require macOS Accessibility/Automation permissions on Herald.

## Natural language Odoo and Calendar via Max

Max can answer selected natural-language Odoo questions through the Herald Agent Harness.

Working examples:

```text
Max Who is the owner of Abby in Odoo?
Max Odoo status
Max what is today's training schedule?
```

The first implemented high-value Odoo path is horse/owner lookup against the custom `x_horses` model. It searches registered name, display/name fields, and barn name, then returns the Odoo owner/contact info.

Ledger also has a deterministic wormer-count route for horse inventory questions mentioning wormer/dewormer:

- Horse inventory lives in Odoo model `x_horses`.
- `Windance Owned` and `Training` refer to the horse Kanban stage field `x_studio_stage_id`, not `x_studio_status`.
- Count records in Kanban stages `Windance Owned` or `Training`.
- Ponies/minis and horses with Odoo age 1 year and under receive 1/2 syringe.
- Two half-dose animals share one syringe.
- Horses over 1 year old receive one full syringe.
- Physical syringes needed = full-dose animal count + `ceil(half-dose animal count / 2)`.

Working example:

```text
Max, please count the horses and ponies in Odoo that are either Windance Owned or in Training and tell me how many wormers I need.
Max, how many wormers do we need?
```

Ledger also has a deterministic training schedule route:

- The training/work schedule is in Odoo, not Google Calendar.
- Main model: `x_work_schedule`
- Current schedule record: `id 22`, display `Work Schedule`
- Line model: `x_work_schedule_line_a873e`
- Horse/barn display field: `x_name`
- Horse link field: `x_studio_horse`
- Current schedule rows must be filtered with `x_work_schedule_id = 22` to avoid old/unlinked rows.
- Day fields:
  - Monday: `x_studio_monday`
  - Tuesday: `x_studio_tuesday`
  - Wednesday: `x_studio_wednesday`
  - Thursday: `x_studio_thrusday` — Odoo field typo is intentional
  - Friday: `x_studio_friday`
  - Saturday: `x_studio_saturday`
  - Sunday: `x_studio_sunday`
- Endpoint: `GET http://192.168.36.21:8791/training/today`
- Chat trigger: `Max, what is today's training schedule?`
- Daily Shawn report: `com.windance.daily-training-schedule` runs `/Users/herald/services/agent-harness/daily_training_schedule.py` at 7:00 AM and sends to `+16054403400`.
- Each daily training report is also saved as durable memory under `daily_training_schedule/YYYY_MM_DD` and vector-indexed. Dated questions such as `What was the training schedule on July 1, 2026?` should use the saved historical snapshot instead of re-reading the current Odoo schedule.

Calendar is also available through Google Workspace:

```text
Max what is on my calendar?
Max what is on my schedule?
```

Calendar write access is enabled, but mutation is approval-backed.

Current supported text format:

```text
Max add appointment 2026-07-01 14:30 for 45 minutes: Call James about Abby
Max approve 1234abcd
Max reject 1234abcd
```

Supported approval-backed action APIs:

- `calendar.create`
- `calendar.delete`
- `gmail.mark_read`
- `gmail.archive`
- `gmail.create_draft`

Gmail and Calendar read/summarize operations are direct. Gmail/Calendar mutations must be represented as pending approvals first, then explicitly approved.

## Odoo connector

The Herald Agent Harness has an Odoo SaaS connector installed and authenticated read-only.

- Config file: `/Users/herald/.config/agent-harness/odoo.json`
- Example file: `/Users/herald/.config/agent-harness/odoo.example.json`
- Status endpoint: `GET http://192.168.36.21:8791/odoo/status`
- Search endpoint: `POST http://192.168.36.21:8791/odoo/search`
- Partner lookup endpoint: `GET http://192.168.36.21:8791/odoo/partners?q=NAME`
- Fields endpoint: `GET http://192.168.36.21:8791/odoo/model/res.partner/fields`

Current Odoo config:

- URL: `https://reflectsody-llc.odoo.com`
- Database: `reflectsody-llc`
- Username: `william@reflectsody.com`
- Authentication status: working as of 2026-06-29

If credentials need to be changed later, update `odoo.json` with:

```json
{
  "url": "https://your-company.odoo.com",
  "database": "your_odoo_database_name",
  "username": "your_odoo_login_email",
  "api_key": "your_odoo_api_key"
}
```

Then restart/check:

```sh
ssh HERALD 'launchctl kickstart -k gui/$(id -u)/com.windance.agent-harness'
ssh HERALD 'curl -sS http://127.0.0.1:8791/odoo/status'
```

The connector currently exposes read-only operations. Any write operations to Odoo should be added behind the approval queue first.

## Useful commands

Check harness:

```sh
ssh HERALD 'curl -sS http://127.0.0.1:8791/health'
```

Restart harness:

```sh
ssh HERALD 'launchctl kickstart -k gui/$(id -u)/com.windance.agent-harness'
```

Test a message:

```sh
ssh HERALD 'curl -sS -X POST http://127.0.0.1:8791/message -H "Content-Type: application/json" -d "{\"message\":\"summarize my email\",\"channel\":\"ssh-test\",\"user\":\"william\"}"'
```

Restart SAL Node-RED:

```sh
ssh SAL 'launchctl kickstart -k gui/$(id -u)/com.zuzu.nodered'
```
