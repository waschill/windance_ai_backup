#!/usr/bin/env python3
"""Small LAN bridge so Node-RED and other homelab tools can talk to HERALD."""

from __future__ import annotations

import json
import os
import subprocess
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone
from html import escape
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse


HOST = os.getenv("HERALD_BRIDGE_HOST", "0.0.0.0")
PORT = int(os.getenv("HERALD_BRIDGE_PORT", "8790"))
OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL", "http://192.168.36.10:11434")
DEFAULT_MODEL = os.getenv("HERALD_BRIDGE_MODEL", "gpt-oss:20b")


def json_response(handler: BaseHTTPRequestHandler, status: int, payload: dict) -> None:
    body = json.dumps(payload, indent=2).encode("utf-8")
    handler.send_response(status)
    handler.send_header("Content-Type", "application/json")
    handler.send_header("Content-Length", str(len(body)))
    handler.end_headers()
    handler.wfile.write(body)


def html_response(handler: BaseHTTPRequestHandler, status: int, body: str) -> None:
    encoded = body.encode("utf-8")
    handler.send_response(status)
    handler.send_header("Content-Type", "text/html; charset=utf-8")
    handler.send_header("Content-Length", str(len(encoded)))
    handler.end_headers()
    handler.wfile.write(encoded)


def read_json(handler: BaseHTTPRequestHandler) -> dict:
    content_length = int(handler.headers.get("Content-Length", "0") or "0")
    if content_length <= 0:
        return {}
    raw = handler.rfile.read(content_length)
    if not raw:
        return {}
    return json.loads(raw.decode("utf-8"))


def ask_ollama(prompt: str, model: str = DEFAULT_MODEL) -> str:
    request_payload = {
        "model": model,
        "messages": [
            {
                "role": "system",
                "content": (
                    "You are HERALD, the homelab Hermes agent boss. "
                    f"You are being served by Ollama on HAL at {OLLAMA_BASE_URL}, "
                    f"using model {model}. "
                    "If asked what model/backend you are using, answer with those exact facts. "
                    "Do not claim to be GPT-4, GPT-4 Turbo, Claude, OpenAI-hosted, or any other cloud model. "
                    "Be concise, practical, and useful for Node-RED automations."
                ),
            },
            {"role": "user", "content": prompt},
        ],
        "stream": False,
    }
    completed = subprocess.run(
        [
            "/usr/bin/curl",
            "-fsS",
            "--max-time",
            "120",
            "-H",
            "Content-Type: application/json",
            "--data-binary",
            "@-",
            f"{OLLAMA_BASE_URL.rstrip('/')}/v1/chat/completions",
        ],
        input=json.dumps(request_payload),
        text=True,
        capture_output=True,
        check=True,
    )
    data = json.loads(completed.stdout)
    return data["choices"][0]["message"]["content"]


def call_ollama_chat(payload: dict) -> dict:
    """Forward an OpenAI-compatible chat request to Ollama with safe defaults.

    Hermes relies on OpenAI-style tool calls for MCP integrations such as
    Google Workspace. Preserve those fields when they are present; otherwise
    Herald can talk but cannot actually use email/calendar tools.
    """
    messages = payload.get("messages")
    if not isinstance(messages, list) or not messages:
        messages = [{"role": "user", "content": str(payload.get("prompt") or "")}]

    model = str(payload.get("model") or DEFAULT_MODEL).strip() or DEFAULT_MODEL
    forwarded: dict = {
        "model": model,
        "messages": messages,
        "stream": False,
    }
    for key in (
        "temperature",
        "top_p",
        "max_tokens",
        "presence_penalty",
        "frequency_penalty",
        "stop",
        "tools",
        "tool_choice",
        "parallel_tool_calls",
        "response_format",
    ):
        if key in payload and payload[key] not in (None, ""):
            forwarded[key] = payload[key]

    completed = subprocess.run(
        [
            "/usr/bin/curl",
            "-fsS",
            "--max-time",
            "180",
            "-H",
            "Content-Type: application/json",
            "--data-binary",
            "@-",
            f"{OLLAMA_BASE_URL.rstrip('/')}/v1/chat/completions",
        ],
        input=json.dumps(forwarded),
        text=True,
        capture_output=True,
        check=True,
    )
    return json.loads(completed.stdout)


def openai_models_response(handler: BaseHTTPRequestHandler) -> None:
    payload = {
        "object": "list",
        "data": [
            {
                "id": DEFAULT_MODEL,
                "object": "model",
                "created": int(time.time()),
                "owned_by": "ollama-on-hal",
            }
        ],
    }
    json_response(handler, 200, payload)


def openai_chat_response(handler: BaseHTTPRequestHandler, payload: dict) -> None:
    wants_stream = bool(payload.get("stream"))
    data = call_ollama_chat(payload)
    choice = (data.get("choices") or [{}])[0]
    message = choice.get("message") or {}
    content = message.get("content") or ""
    model = data.get("model") or payload.get("model") or DEFAULT_MODEL

    if message.get("tool_calls"):
        if wants_stream:
            handler.send_response(200)
            handler.send_header("Content-Type", "text/event-stream; charset=utf-8")
            handler.send_header("Cache-Control", "no-cache")
            handler.send_header("Connection", "keep-alive")
            handler.end_headers()

            stream_id = data.get("id") or f"chatcmpl-herald-{int(time.time())}"
            created = data.get("created") or int(time.time())
            role_chunk = {
                "id": stream_id,
                "object": "chat.completion.chunk",
                "created": created,
                "model": model,
                "choices": [{"index": 0, "delta": {"role": "assistant"}, "finish_reason": None}],
            }
            handler.wfile.write(f"data: {json.dumps(role_chunk)}\n\n".encode("utf-8"))

            for tool_call in message["tool_calls"]:
                function = tool_call.get("function") or {}
                tool_chunk = {
                    "id": stream_id,
                    "object": "chat.completion.chunk",
                    "created": created,
                    "model": model,
                    "choices": [
                        {
                            "index": 0,
                            "delta": {
                                "tool_calls": [
                                    {
                                        "index": tool_call.get("index", 0),
                                        "id": tool_call.get("id"),
                                        "type": tool_call.get("type") or "function",
                                        "function": {
                                            "name": function.get("name"),
                                            "arguments": function.get("arguments") or "",
                                        },
                                    }
                                ]
                            },
                            "finish_reason": None,
                        }
                    ],
                }
                handler.wfile.write(f"data: {json.dumps(tool_chunk)}\n\n".encode("utf-8"))

            done = {
                "id": stream_id,
                "object": "chat.completion.chunk",
                "created": created,
                "model": model,
                "choices": [{"index": 0, "delta": {}, "finish_reason": choice.get("finish_reason") or "tool_calls"}],
            }
            handler.wfile.write(f"data: {json.dumps(done)}\n\n".encode("utf-8"))
            handler.wfile.write(b"data: [DONE]\n\n")
            return

        response = {
            "id": data.get("id") or f"chatcmpl-herald-{int(time.time())}",
            "object": "chat.completion",
            "created": data.get("created") or int(time.time()),
            "model": model,
            "choices": [
                {
                    "index": 0,
                    "message": {
                        "role": message.get("role") or "assistant",
                        "content": message.get("content") or "",
                        "tool_calls": message["tool_calls"],
                    },
                    "finish_reason": choice.get("finish_reason") or "tool_calls",
                }
            ],
            "usage": data.get("usage") or {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0},
        }
        json_response(handler, 200, response)
        return

    if wants_stream:
        handler.send_response(200)
        handler.send_header("Content-Type", "text/event-stream; charset=utf-8")
        handler.send_header("Cache-Control", "no-cache")
        handler.send_header("Connection", "keep-alive")
        handler.end_headers()
        chunk = {
            "id": f"chatcmpl-herald-{int(time.time())}",
            "object": "chat.completion.chunk",
            "created": int(time.time()),
            "model": model,
            "choices": [
                {
                    "index": 0,
                    "delta": {"role": "assistant", "content": content},
                    "finish_reason": None,
                }
            ],
        }
        handler.wfile.write(f"data: {json.dumps(chunk)}\n\n".encode("utf-8"))
        done = {
            "id": chunk["id"],
            "object": "chat.completion.chunk",
            "created": int(time.time()),
            "model": model,
            "choices": [{"index": 0, "delta": {}, "finish_reason": "stop"}],
        }
        handler.wfile.write(f"data: {json.dumps(done)}\n\n".encode("utf-8"))
        handler.wfile.write(b"data: [DONE]\n\n")
        return

    response = {
        "id": f"chatcmpl-herald-{int(time.time())}",
        "object": "chat.completion",
        "created": int(time.time()),
        "model": model,
        "choices": [
            {
                "index": 0,
                "message": {"role": "assistant", "content": content},
                "finish_reason": choice.get("finish_reason") or "stop",
            }
        ],
        "usage": data.get("usage") or {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0},
    }
    json_response(handler, 200, response)


def chat_page(reply: str = "", message: str = "", error: str = "") -> str:
    escaped_reply = escape(reply)
    escaped_message = escape(message)
    escaped_error = escape(error)
    transcript = ""
    if message:
        transcript += f"<section class='bubble user'><div class='label'>You</div><p>{escaped_message}</p></section>"
    if reply:
        transcript += f"<section class='bubble herald'><div class='label'>HERALD</div><p>{escaped_reply}</p></section>"
    if error:
        transcript += f"<section class='bubble error'><div class='label'>Error</div><p>{escaped_error}</p></section>"

    return f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Chat with HERALD</title>
  <style>
    :root {{ color-scheme: dark; }}
    body {{
      margin: 0;
      font: 16px -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      background: #0f172a;
      color: #e2e8f0;
    }}
    main {{
      max-width: 780px;
      margin: 0 auto;
      padding: 18px;
    }}
    h1 {{ margin: 8px 0 4px; font-size: 28px; }}
    .sub {{ margin: 0 0 18px; color: #94a3b8; }}
    form {{
      display: grid;
      gap: 10px;
      background: #1e293b;
      border-radius: 16px;
      padding: 14px;
      box-shadow: 0 8px 24px #0005;
      position: sticky;
      top: 0;
    }}
    textarea {{
      min-height: 130px;
      resize: vertical;
      border-radius: 12px;
      border: 1px solid #475569;
      padding: 12px;
      background: #020617;
      color: #e2e8f0;
      font: inherit;
    }}
    button {{
      border: 0;
      border-radius: 12px;
      padding: 12px 14px;
      background: #2563eb;
      color: white;
      font: inherit;
      font-weight: 700;
    }}
    .bubble {{
      margin: 14px 0;
      border-radius: 16px;
      padding: 14px;
      white-space: pre-wrap;
      line-height: 1.45;
    }}
    .user {{ background: #334155; }}
    .herald {{ background: #0f766e; }}
    .error {{ background: #7f1d1d; }}
    .label {{
      font-size: 12px;
      letter-spacing: .08em;
      text-transform: uppercase;
      color: #cbd5e1;
      margin-bottom: 6px;
      font-weight: 800;
    }}
    .links {{ margin-top: 14px; color: #94a3b8; font-size: 14px; }}
    a {{ color: #93c5fd; }}
  </style>
</head>
<body>
  <main>
    <h1>Chat with HERALD</h1>
    <p class="sub">HERALD is using Ollama on HAL through the local bridge. Current model: <code>{escape(DEFAULT_MODEL)}</code>.</p>
    <form method="post" action="/chat">
      <textarea name="message" autofocus placeholder="Ask HERALD something..."></textarea>
      <button type="submit">Send to HERALD</button>
    </form>
    {transcript}
    <p class="links"><a href="/health">Health</a> · API endpoint: <code>POST /message</code></p>
  </main>
</body>
</html>"""


class HeraldBridge(BaseHTTPRequestHandler):
    server_version = "HeraldBridge/0.1"

    def log_message(self, fmt: str, *args) -> None:
        print(
            json.dumps(
                {
                    "time": datetime.now(timezone.utc).isoformat(),
                    "client": self.client_address[0],
                    "message": fmt % args,
                }
            ),
            flush=True,
        )

    def do_GET(self) -> None:
        path = urlparse(self.path).path
        if path == "/health":
            json_response(
                self,
                200,
                {
                    "status": "ok",
                    "service": "herald-bridge",
                    "host": os.uname().nodename,
                    "ollama_base_url": OLLAMA_BASE_URL,
                    "default_model": DEFAULT_MODEL,
                    "time": datetime.now(timezone.utc).isoformat(),
                },
            )
            return
        if path in ("/v1/models", "/models"):
            openai_models_response(self)
            return
        if path == "/chat":
            html_response(self, 200, chat_page())
            return
        if path == "/message":
            html_response(
                self,
                405,
                chat_page(error="The /message endpoint is for POST JSON. Use /chat in a browser."),
            )
            return
        json_response(self, 404, {"detail": "Not found"})

    def do_POST(self) -> None:
        path = urlparse(self.path).path
        if path == "/v1/chat/completions":
            try:
                payload = read_json(self)
                openai_chat_response(self, payload)
            except subprocess.CalledProcessError as error:
                json_response(
                    self,
                    502,
                    {
                        "error": {
                            "message": f"Ollama request failed: {error.stderr or error}",
                            "type": "upstream_error",
                        }
                    },
                )
            except Exception as error:
                json_response(self, 500, {"error": {"message": str(error), "type": "server_error"}})
            return

        if path == "/chat":
            try:
                content_length = int(self.headers.get("Content-Length", "0") or "0")
                raw = self.rfile.read(content_length).decode("utf-8")
                form = parse_qs(raw)
                prompt = str(form.get("message", [""])[0]).strip()
                if not prompt:
                    html_response(self, 400, chat_page(error="Please type a message first."))
                    return
                reply = ask_ollama(prompt)
                html_response(self, 200, chat_page(reply=reply, message=prompt))
            except Exception as error:
                html_response(self, 500, chat_page(error=str(error)))
            return

        if path not in ("/message", "/task"):
            json_response(self, 404, {"detail": "Not found"})
            return
        try:
            payload = read_json(self)
            prompt = str(payload.get("message") or payload.get("prompt") or "").strip()
            model = str(payload.get("model") or DEFAULT_MODEL).strip()
            if not prompt:
                json_response(self, 400, {"detail": "message or prompt is required"})
                return
            reply = ask_ollama(prompt, model=model)
            json_response(
                self,
                200,
                {
                    "status": "ok",
                    "service": "herald-bridge",
                    "model": model,
                    "reply": reply,
                    "time": datetime.now(timezone.utc).isoformat(),
                },
            )
        except (urllib.error.URLError, subprocess.CalledProcessError) as error:
            json_response(self, 502, {"status": "error", "detail": f"Ollama request failed: {error}"})
        except Exception as error:
            json_response(self, 500, {"status": "error", "detail": str(error)})


def main() -> None:
    server = ThreadingHTTPServer((HOST, PORT), HeraldBridge)
    print(f"HERALD bridge listening on {HOST}:{PORT}", flush=True)
    server.serve_forever()


if __name__ == "__main__":
    main()
