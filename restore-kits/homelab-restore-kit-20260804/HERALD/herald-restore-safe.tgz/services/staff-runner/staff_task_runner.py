#!/usr/bin/env python3
from __future__ import annotations

import datetime as dt
import json
import os
import re
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any

HARNESS = os.environ.get('HERALD_HARNESS_URL', 'http://127.0.0.1:8791').rstrip('/')
LOCK = Path(os.environ.get('STAFF_RUNNER_LOCK', str(Path.home() / '.local' / 'state' / 'staff-runner.lock')))
LOG_DIR = Path(os.environ.get('STAFF_RUNNER_LOG_DIR', str(Path.home() / 'logs' / 'staff-runner')))
STATE_FILE = Path(os.environ.get('STAFF_RUNNER_NOTIFY_STATE', str(Path.home() / '.local' / 'state' / 'staff-runner-notified.json')))
MAX_NOTIFY_URL = os.environ.get('MAX_NOTIFY_URL', 'http://192.168.36.22:1880/codex/send-imessage')
WILLIAM_PHONE = os.environ.get('WILLIAM_PHONE', '+16054401255')
SKIP_ASSIGNEES = {'Forge'}
AUTO_ASSIGNEES = {'Sentinel', 'Iris', 'Ledger', 'Scout', 'Archivist', 'Athena', 'Max', 'Herald'}
ASSIGNEE_ORDER = {'Sentinel': 10, 'Iris': 20, 'Ledger': 30, 'Scout': 40, 'Max': 50, 'Herald': 60, 'Athena': 80, 'Archivist': 90}

HOSTS = {
    'HAL': {'ip': '192.168.36.10', 'ssh_alias': 'HAL', 'checks': [('Ollama', 'http://192.168.36.10:11434/api/tags')]},
    'AL': {'ip': '192.168.36.20', 'ssh_alias': 'AL', 'checks': []},
    'SAL': {'ip': '192.168.36.22', 'ssh_alias': 'SAL', 'checks': [('Node-RED', 'http://192.168.36.22:1880/')]},
    'HERALD': {'ip': '192.168.36.21', 'ssh_alias': 'HERALD', 'checks': [('Agent Harness', 'http://127.0.0.1:8791/health'), ('Hermes Dashboard', 'http://127.0.0.1:9120/staff')]},
    'Odyssey': {'ip': '192.168.36.31', 'ssh_alias': 'Odyssey', 'checks': []},
    'TMA-1': {'ip': '192.168.36.131', 'ssh_alias': 'TMA-1', 'checks': []},
    'TMA-2': {'ip': '192.168.36.133', 'ssh_alias': 'TMA-2', 'checks': []},
    'REFWeb': {'ip': '64.251.177.195', 'ssh_alias': 'REFWeb', 'checks': [('Apache', 'http://64.251.177.195/')]},
}


def log(msg: str) -> None:
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    line = f"{dt.datetime.now().isoformat()} {msg}"
    print(line, flush=True)
    with (LOG_DIR / 'staff-runner.log').open('a') as f:
        f.write(line + '\n')


def get_json(url: str, timeout: int = 30) -> dict[str, Any]:
    with urllib.request.urlopen(url, timeout=timeout) as r:
        return json.load(r)


def post_json(url: str, payload: dict[str, Any], timeout: int = 120) -> dict[str, Any]:
    req = urllib.request.Request(url, data=json.dumps(payload).encode('utf-8'), headers={'Content-Type': 'application/json'}, method='POST')
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.load(r)


def complete_task(task: dict[str, Any], result: str, status: str = 'completed', by: str = 'Herald staff-runner') -> None:
    post_json(f"{HARNESS}/staff/tasks/{task['id']}/complete", {'result': result[:50000], 'status': status, 'completed_by': by}, timeout=60)



def load_notify_state() -> set[str]:
    try:
        data = json.loads(STATE_FILE.read_text())
        return set(data.get('notified_task_ids') or [])
    except Exception:
        return set()


def save_notify_state(ids: set[str]) -> None:
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    STATE_FILE.write_text(json.dumps({'notified_task_ids': sorted(ids)[-1000:]}, indent=2))



def send_local_messages(message: str, to: str = WILLIAM_PHONE, timeout: int = 8) -> tuple[bool, str]:
    safe = message.replace('\\', '\\\\').replace('"', '\\"').replace('\n', '\\n')
    safe_to = to.replace('"', '')
    script = f'tell application "Messages" to send "{safe}" to buddy "{safe_to}"'
    try:
        proc = subprocess.run(['/usr/bin/osascript', '-e', script], text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout)
        if proc.returncode == 0:
            return True, 'Herald local Messages'
        return False, f'osascript {proc.returncode}: {(proc.stderr or proc.stdout)[:250]}'
    except subprocess.TimeoutExpired:
        return False, 'Herald local Messages timed out'
    except Exception as exc:
        return False, f'{type(exc).__name__}: {str(exc)[:250]}'

def send_max_notification(message: str, urgent: bool = False) -> tuple[bool, str]:
    prefix = 'URGENT: ' if urgent and not message.upper().startswith('URGENT') else ''
    outbound = prefix + message
    local_ok, local_detail = send_local_messages(outbound)
    if local_ok:
        return True, local_detail
    payload = {'to': WILLIAM_PHONE, 'message': outbound}
    try:
        post_json(MAX_NOTIFY_URL, payload, timeout=20)
        return True, f'SAL Max/iMessage after local failed: {local_detail}'
    except Exception as exc:
        return False, f'local failed: {local_detail}; SAL failed: {type(exc).__name__}: {str(exc)[:300]}'


def compact_task_result(task: dict[str, Any], max_chars: int = 850) -> str:
    result = str(task.get('result') or '').strip()
    result = re.sub(r'\n{3,}', '\n\n', result)
    if len(result) > max_chars:
        result = result[: max_chars - 1].rstrip() + '?'
    return result


def notify_task_result(task: dict[str, Any]) -> None:
    status = str(task.get('status') or '').lower()
    if status not in {'completed', 'blocked', 'failed', 'cancelled'}:
        return
    if status == 'cancelled' and str(task.get('channel') or '').startswith('codex-'):
        return
    assignee = task.get('assignee') or 'Staff'
    title = task.get('title') or '(untitled task)'
    task_id = str(task.get('id') or '')[:8]
    result = compact_task_result(task)
    message = f"{assignee} task {status}: {title} #{task_id}\n\n{result}\n\nReview: https://herald.reflectsody.com/staff"
    ok, detail = send_max_notification(message, urgent=(status in {'blocked', 'failed'}))
    log(f"notification for {task_id}: {detail}")


def poll_terminal_task_notifications() -> None:
    notified = load_notify_state()
    changed = False
    terminal: list[dict[str, Any]] = []
    for status in ['completed', 'blocked', 'failed']:
        try:
            terminal.extend(get_json(f'{HARNESS}/staff/tasks?status={status}&limit=50', timeout=30).get('tasks') or [])
        except Exception as exc:
            log(f'notification poll failed for {status}: {exc}')
    terminal.sort(key=lambda t: str(t.get('completed_at') or t.get('updated_at') or ''))
    for task in terminal:
        task_id = str(task.get('id') or '')
        if not task_id or task_id in notified:
            continue
        notify_task_result(task)
        notified.add(task_id)
        changed = True
    if changed:
        save_notify_state(notified)

def harness_message(message: str, channel: str = 'staff-runner', user: str = 'staff-runner') -> str:
    data = post_json(f'{HARNESS}/message', {'message': message, 'channel': channel, 'user': user}, timeout=240)
    return str(data.get('reply') or '').strip()


def http_probe(url: str, timeout: int = 5) -> tuple[bool, str]:
    try:
        req = urllib.request.Request(url, method='GET')
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return True, f'HTTP {r.status}'
    except urllib.error.HTTPError as exc:
        # Login redirects/401s still prove the service is listening.
        if exc.code in {301, 302, 401, 403}:
            return True, f'HTTP {exc.code}'
        return False, f'HTTP {exc.code}'
    except Exception as exc:
        return False, f'{type(exc).__name__}: {str(exc)[:120]}'


def ping_host(ip: str) -> tuple[bool, str]:
    # macOS ping: -c count, -t ttl. Use a short subprocess timeout for safety.
    try:
        proc = subprocess.run(['/sbin/ping', '-c', '1', ip], text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=4)
        first = (proc.stdout or '').splitlines()[0] if proc.stdout else ''
        return proc.returncode == 0, first[:160]
    except Exception as exc:
        return False, f'{type(exc).__name__}: {str(exc)[:120]}'


def ssh_probe(alias: str) -> tuple[bool, str]:
    try:
        proc = subprocess.run(
            ['/usr/bin/ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=5', '-o', 'LogLevel=ERROR', alias, 'hostname; uptime'],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            timeout=10,
        )
        output = ' | '.join(line.strip() for line in (proc.stdout or '').splitlines() if line.strip())
        if proc.returncode == 0:
            return True, output[:220] or 'ssh ok'
        return False, output[:220] or f'ssh exited {proc.returncode}'
    except Exception as exc:
        return False, f'{type(exc).__name__}: {str(exc)[:120]}'


def execute_sentinel(task: dict[str, Any]) -> tuple[str, str]:
    lines = ['Sentinel network/service check:', '']
    all_ok = True
    for name, info in HOSTS.items():
        ok, detail = ping_host(info['ip'])
        all_ok = all_ok and ok
        lines.append(f"- {name} {info['ip']}: {'UP' if ok else 'DOWN'} ({detail})")
        alias = info.get('ssh_alias')
        if alias:
            ssh_ok, ssh_detail = ssh_probe(alias)
            # HAL may be reachable by ping/Ollama while Windows SSH still needs the
            # administrator-authorized-keys one-time fix. Treat that as a warning,
            # not a full Sentinel outage.
            if name != 'HAL':
                all_ok = all_ok and ssh_ok
            lines.append(f"  - SSH: {'OK' if ssh_ok else 'WARN'} ({ssh_detail})")
        for label, url in info.get('checks', []):
            service_ok, service_detail = http_probe(url)
            all_ok = all_ok and service_ok
            lines.append(f"  - {label}: {'OK' if service_ok else 'FAIL'} ({service_detail})")
    lines.append('')
    lines.append('No changes made. SyncThing was not inspected or touched.')
    return '\n'.join(lines), 'completed' if all_ok else 'blocked'


def execute_iris(task: dict[str, Any]) -> tuple[str, str]:
    req = (task.get('request') or '').lower()
    lines = ['Iris Gmail/Calendar report:', '']
    try:
        if any(w in req for w in ['email', 'gmail', 'inbox', 'unread']):
            items = get_json(f'{HARNESS}/email/unread?limit=10', timeout=60).get('items') or []
            if not items:
                lines.append('Unread inbox: no unread Gmail messages returned by the harness query.')
            else:
                lines.append(f'Unread inbox: {len(items)} message(s) shown.')
                for item in items[:10]:
                    sender = re.sub(r'\s*<[^>]+>', '', str(item.get('from') or 'Unknown')).strip(' "')
                    subject = str(item.get('subject') or '(no subject)').strip()
                    labels = ','.join(item.get('labels') or [])
                    important = 'IMPORTANT' in labels.upper() or any(term in (sender + ' ' + subject).lower() for term in ['urgent','invoice','payment','security','password','action required'])
                    mark = 'important' if important else 'normal'
                    lines.append(f"- [{mark}] {sender}: {subject}")
        if any(w in req for w in ['calendar', 'appointment', 'schedule', 'today', 'tomorrow']) or 'email' not in req:
            events = get_json(f'{HARNESS}/calendar/upcoming?limit=10&days=7', timeout=60).get('items') or []
            lines.append('')
            if not events:
                lines.append('Calendar: no upcoming events returned for the next 7 days.')
            else:
                lines.append(f'Calendar: {len(events)} upcoming item(s).')
                for e in events[:10]:
                    lines.append(f"- {e.get('summary') or '(no title)'} at {e.get('start')}")
        lines.append('')
        lines.append('No Gmail or Calendar changes were made. Writes require William approval before execution.')
        return '\n'.join(lines), 'completed'
    except Exception as exc:
        return f'Iris could not complete the Gmail/Calendar task: {type(exc).__name__}: {str(exc)[:700]}', 'failed'


def execute_ledger(task: dict[str, Any]) -> tuple[str, str]:
    request = str(task.get('request') or '')
    lowered = request.lower()
    try:
        if 'training schedule' in lowered or 'work schedule' in lowered:
            if 'tomorrow' in lowered:
                target = (dt.datetime.now().astimezone().date() + dt.timedelta(days=1)).isoformat()
                data = get_json(f'{HARNESS}/training/today?date={urllib.parse.quote(target)}', timeout=90)
            else:
                data = get_json(f'{HARNESS}/training/today', timeout=90)
            return str(data.get('reply') or 'No training schedule reply returned.'), 'completed'
        # Let the harness deterministic Odoo router answer other read-only Odoo questions.
        reply = harness_message(request if 'odoo' in lowered else f'In Odoo, {request}', channel='staff-ledger', user='ledger')
        return reply, 'completed'
    except Exception as exc:
        return f'Ledger could not complete the Odoo read-only task: {type(exc).__name__}: {str(exc)[:700]}', 'failed'


def execute_scout(task: dict[str, Any]) -> tuple[str, str]:
    request = str(task.get('request') or '')
    query = re.sub(r'^(research|search|look up|find)\s+', '', request, flags=re.I).strip() or request
    try:
        reply = harness_message(f'Research {query}', channel='staff-scout', user='scout')
        return reply, 'completed'
    except Exception as exc:
        return f'Scout could not complete web research: {type(exc).__name__}: {str(exc)[:700]}', 'failed'


def related_sibling_tasks(task: dict[str, Any]) -> list[dict[str, Any]]:
    title = str(task.get('title') or '')
    stem = title.split(':', 1)[0].strip().lower()
    if not stem:
        return []
    all_tasks = []
    for status in ['completed', 'blocked', 'failed', 'pending']:
        try:
            all_tasks.extend(get_json(f'{HARNESS}/staff/tasks?status={status}&limit=100', timeout=60).get('tasks') or [])
        except Exception:
            pass
    return [t for t in all_tasks if str(t.get('id')) != str(task.get('id')) and str(t.get('title') or '').split(':', 1)[0].strip().lower() == stem]


def execute_archivist(task: dict[str, Any]) -> tuple[str, str]:
    request = str(task.get('request') or '')
    title = str(task.get('title') or 'staff_task')
    siblings = related_sibling_tasks(task)
    unfinished = [t for t in siblings if t.get('status') == 'pending']
    if unfinished and any(term in request.lower() for term in ['summary', 'results', 'after', 'when complete']):
        names = ', '.join(f"{t.get('assignee')} #{str(t.get('id'))[:8]}" for t in unfinished[:8])
        return f'Archivist is waiting for related staff results before preserving the final summary. Still pending: {names}', 'blocked'
    key = re.sub(r'[^a-zA-Z0-9]+', '_', title.lower()).strip('_')[:80] or task['id'][:8]
    lines = [
        f"Staff task archived {dt.datetime.now().isoformat()}",
        '',
        f"Title: {title}",
        f"Assignee: {task.get('assignee')}",
        f"Requester: {task.get('requester')}",
        'Request:',
        request,
    ]
    completed_siblings = [t for t in siblings if t.get('status') in {'completed', 'blocked', 'failed'}]
    if completed_siblings:
        lines.extend(['', 'Related staff results:'])
        for t in sorted(completed_siblings, key=lambda x: str(x.get('assignee') or '')):
            result = str(t.get('result') or '').strip()
            lines.append(f"- {t.get('assignee')} [{t.get('status')}] {t.get('title')}: {result[:1200]}")
    value = '\n'.join(lines)
    try:
        post_json(f'{HARNESS}/memory', {'kind': 'staff_task_archive', 'key': key, 'value': value, 'confidence': 0.9, 'source': f"staff_task:{task['id']}"}, timeout=60)
        return f'Archivist saved durable memory staff_task_archive/{key}.\n\n{value}', 'completed'
    except Exception as exc:
        return f'Archivist could not save memory: {type(exc).__name__}: {str(exc)[:700]}', 'failed'


def execute_athena(task: dict[str, Any]) -> tuple[str, str]:
    request = str(task.get('request') or '')
    # Lightweight QA: look for referenced recent completed tasks with same source/title stem.
    source = str(task.get('source') or '')
    tasks = get_json(f'{HARNESS}/staff/tasks?status=completed&limit=20', timeout=60).get('tasks') or []
    related = [t for t in tasks if source and t.get('source') == source and t.get('id') != task.get('id')]
    lines = ['Athena QA review:', '']
    if related:
        lines.append(f'Reviewed {len(related)} related completed task result(s).')
        for t in related[:5]:
            result = str(t.get('result') or '')
            confidence = 'medium'
            if any(w in result.lower() for w in ['failed', 'could not', 'blocked', 'error', 'uncertain']):
                confidence = 'low-to-medium'
            elif len(result) > 200:
                confidence = 'medium-to-high'
            lines.append(f"- {t.get('assignee')}: {t.get('title')} ? confidence {confidence}.")
        lines.append('')
        lines.append('QA decision: related results are accepted as staff output, but any external write, deletion, service unload, or credential change still requires William approval.')
    else:
        lines.append('No related completed task result was found to QA yet. I reviewed the request itself and found no production authority granted.')
        lines.append('QA decision: blocked until there is a concrete result to verify, unless William only wanted a checklist.')
        if 'checklist' in request.lower() or 'prepare' in request.lower():
            lines.append('Checklist: verify evidence, confirm no hallucinated facts, compare numbers/source rows, check dates, require approval for writes/deletes, and report confidence.')
            return '\n'.join(lines), 'completed'
        return '\n'.join(lines), 'blocked'
    return '\n'.join(lines), 'completed'


def execute_max_or_herald(task: dict[str, Any]) -> tuple[str, str]:
    request = str(task.get('request') or '')
    try:
        reply = harness_message(request, channel='staff-herald', user=str(task.get('assignee') or 'herald').lower())
        return reply, 'completed'
    except Exception as exc:
        return f'{task.get("assignee")} could not complete the task: {type(exc).__name__}: {str(exc)[:700]}', 'failed'


def execute_task(task: dict[str, Any]) -> tuple[str, str]:
    assignee = str(task.get('assignee') or '')
    if assignee == 'Sentinel':
        return execute_sentinel(task)
    if assignee == 'Iris':
        return execute_iris(task)
    if assignee == 'Ledger':
        return execute_ledger(task)
    if assignee == 'Scout':
        return execute_scout(task)
    if assignee == 'Archivist':
        return execute_archivist(task)
    if assignee == 'Athena':
        return execute_athena(task)
    if assignee in {'Max', 'Herald'}:
        return execute_max_or_herald(task)
    return f'No automatic worker is configured for assignee {assignee}.', 'blocked'


def acquire_lock() -> bool:
    LOCK.parent.mkdir(parents=True, exist_ok=True)
    if LOCK.exists():
        try:
            if time.time() - LOCK.stat().st_mtime < 300:
                return False
        except FileNotFoundError:
            pass
    LOCK.write_text(str(os.getpid()))
    return True


def release_lock() -> None:
    try:
        if LOCK.read_text().strip() == str(os.getpid()):
            LOCK.unlink()
    except FileNotFoundError:
        pass


def main() -> int:
    if not acquire_lock():
        log('another staff-runner appears active')
        return 0
    try:
        pending = get_json(f'{HARNESS}/staff/tasks?status=pending&limit=25', timeout=30).get('tasks') or []
        runnable = [t for t in pending if str(t.get('assignee') or '') in AUTO_ASSIGNEES and str(t.get('assignee') or '') not in SKIP_ASSIGNEES]
        runnable.sort(key=lambda t: ASSIGNEE_ORDER.get(str(t.get('assignee') or ''), 999))
        if not runnable:
            poll_terminal_task_notifications()
            log('no pending automatic staff tasks')
            return 0
        for task in runnable[:10]:
            log(f"processing {task.get('assignee')} task {str(task.get('id'))[:8]}: {task.get('title')}")
            try:
                result, status = execute_task(task)
            except Exception as exc:
                result, status = f"staff-runner failed before completing this task: {type(exc).__name__}: {str(exc)[:1000]}", 'failed'
            complete_task(task, result=result, status=status, by=f"{task.get('assignee')} via Herald staff-runner")
            log(f"posted {status} result for {str(task.get('id'))[:8]}")
            try:
                refreshed = get_json(f"{HARNESS}/staff/tasks/{task['id']}", timeout=30).get('task') or task
                notify_task_result(refreshed)
                notified = load_notify_state(); notified.add(task['id']); save_notify_state(notified)
            except Exception as exc:
                log(f"immediate notification failed for {str(task.get('id'))[:8]}: {exc}")
        poll_terminal_task_notifications()
        return 0
    finally:
        release_lock()


if __name__ == '__main__':
    raise SystemExit(main())
