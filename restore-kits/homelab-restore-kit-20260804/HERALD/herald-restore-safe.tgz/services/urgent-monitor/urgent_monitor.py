#!/usr/bin/env python3
from __future__ import annotations

import base64
import datetime as dt
from email.message import EmailMessage
import json
import os
from pathlib import Path
import subprocess
import time
import urllib.error
import urllib.request
from typing import Any

from google.auth.transport.requests import Request as GoogleRequest
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build

STATE_FILE = Path(os.environ.get('URGENT_MONITOR_STATE', str(Path.home() / '.local' / 'state' / 'urgent-monitor.json')))
LOCK_FILE = Path(os.environ.get('URGENT_MONITOR_LOCK', str(Path.home() / '.local' / 'state' / 'urgent-monitor.lock')))
LOG_DIR = Path(os.environ.get('URGENT_MONITOR_LOG_DIR', str(Path.home() / 'logs' / 'urgent-monitor')))
MAX_NOTIFY_URL = os.environ.get('MAX_NOTIFY_URL', 'http://192.168.36.22:1880/codex/send-imessage')
WILLIAM_PHONE = os.environ.get('WILLIAM_PHONE', '+16054401255')
WILLIAM_EMAIL = os.environ.get('WILLIAM_EMAIL', 'william@reflectsody.com')
GOOGLE_TOKEN_FILE = Path(os.environ.get('GOOGLE_WORKSPACE_TOKEN_FILE', str(Path.home() / '.config' / 'google-workspace' / 'google-token.json')))
SCOPES = ['https://mail.google.com/', 'https://www.googleapis.com/auth/calendar.events']

CHECKS = [
    {'id': 'SAL_HOST', 'name': 'SAL host', 'kind': 'ping', 'target': '192.168.36.22', 'severity': 'urgent', 'why': 'SAL is the communications hub for Node-RED and Max/iMessage.'},
    {'id': 'SAL_NODERED', 'name': 'SAL Node-RED', 'kind': 'http', 'target': 'http://192.168.36.22:1880/', 'severity': 'urgent', 'why': 'Node-RED routes Max/iMessage and scheduled assistant reports.'},
    {'id': 'HERALD_HARNESS', 'name': 'HERALD Agent Harness', 'kind': 'http', 'target': 'http://127.0.0.1:8791/health', 'severity': 'urgent', 'why': 'Herald Agent Harness is the production assistant brain.'},
    {'id': 'HAL_HOST', 'name': 'HAL host', 'kind': 'ping', 'target': '192.168.36.10', 'severity': 'urgent', 'why': 'HAL is William?s daily driver and AI/Codex host.'},
    {'id': 'HERALD_DASHBOARD', 'name': 'HERALD Dashboard', 'kind': 'http', 'target': 'http://127.0.0.1:9120/staff', 'severity': 'important', 'why': 'Dashboard access and Staff Tasks review page.'},
    {'id': 'HAL_OLLAMA', 'name': 'HAL Ollama', 'kind': 'http', 'target': 'http://192.168.36.10:11434/api/tags', 'severity': 'important', 'why': 'Local model service for the assistant stack.'},
]


def log(msg: str) -> None:
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    line = f'{dt.datetime.now().isoformat()} {msg}'
    print(line, flush=True)
    with (LOG_DIR / 'urgent-monitor.log').open('a') as f:
        f.write(line + '\n')


def acquire_lock() -> bool:
    LOCK_FILE.parent.mkdir(parents=True, exist_ok=True)
    if LOCK_FILE.exists():
        try:
            if time.time() - LOCK_FILE.stat().st_mtime < 180:
                return False
        except FileNotFoundError:
            pass
    LOCK_FILE.write_text(str(os.getpid()))
    return True


def release_lock() -> None:
    try:
        if LOCK_FILE.read_text().strip() == str(os.getpid()):
            LOCK_FILE.unlink()
    except FileNotFoundError:
        pass


def load_state() -> dict[str, Any]:
    try:
        return json.loads(STATE_FILE.read_text())
    except Exception:
        return {'checks': {}}


def save_state(state: dict[str, Any]) -> None:
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    STATE_FILE.write_text(json.dumps(state, indent=2, sort_keys=True))


def ping(target: str) -> tuple[bool, str]:
    try:
        proc = subprocess.run(['/sbin/ping', '-c', '1', target], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=4)
        first = (proc.stdout or '').splitlines()[0] if proc.stdout else ''
        return proc.returncode == 0, first[:180]
    except Exception as exc:
        return False, f'{type(exc).__name__}: {str(exc)[:180]}'


def http(target: str) -> tuple[bool, str]:
    try:
        proc = subprocess.run(
            ['/usr/bin/curl', '-sS', '-L', '--max-time', '5', '--connect-timeout', '3', '-o', '/dev/null', '-w', '%{http_code}', target],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=7,
        )
        code_text = (proc.stdout or '').strip()
        if proc.returncode == 0 and code_text.isdigit():
            code = int(code_text)
            return 200 <= code < 500, f'HTTP {code}'
        detail = (proc.stderr or proc.stdout or '').strip().replace('\n', ' ')[:180]
        return False, f'curl {proc.returncode}: {detail}'
    except Exception as exc:
        return False, f'{type(exc).__name__}: {str(exc)[:180]}'


def one_probe(check: dict[str, Any]) -> tuple[bool, str]:
    return ping(check['target']) if check['kind'] == 'ping' else http(check['target'])


def verified_probe(check: dict[str, Any]) -> tuple[bool, list[str]]:
    details = []
    for idx in range(3):
        ok, detail = one_probe(check)
        details.append(detail)
        if ok:
            return True, details
        if idx < 2:
            time.sleep(5)
    return False, details


def post_json(url: str, payload: dict[str, Any], timeout: int = 15) -> dict[str, Any]:
    req = urllib.request.Request(url, data=json.dumps(payload).encode('utf-8'), headers={'Content-Type': 'application/json'}, method='POST')
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.load(resp)


def send_local_messages(message: str, to: str = WILLIAM_PHONE, timeout: int = 3) -> tuple[bool, str]:
    safe = message.replace('\\', '\\\\').replace('"', '\\"').replace('\n', '\\n')
    script = f'tell application "Messages" to send "{safe}" to buddy "{to.replace(chr(34), "")}"'
    try:
        proc = subprocess.run(['/usr/bin/osascript', '-e', script], text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout)
        if proc.returncode == 0:
            return True, 'Herald local Messages'
        return False, f'osascript {proc.returncode}: {(proc.stderr or proc.stdout)[:250]}'
    except subprocess.TimeoutExpired:
        return False, 'Herald local Messages timed out'
    except Exception as exc:
        return False, f'{type(exc).__name__}: {str(exc)[:250]}'


def send_max(message: str) -> tuple[bool, str]:
    try:
        post_json(MAX_NOTIFY_URL, {'to': WILLIAM_PHONE, 'message': message}, timeout=15)
        return True, 'SAL Max/iMessage'
    except Exception as exc:
        return False, f'{type(exc).__name__}: {str(exc)[:250]}'


def gmail_service() -> Any:
    creds = Credentials.from_authorized_user_file(str(GOOGLE_TOKEN_FILE), SCOPES)
    if not creds.valid:
        if creds.expired and creds.refresh_token:
            creds.refresh(GoogleRequest())
        else:
            raise RuntimeError('Google token is not valid and cannot refresh')
    return build('gmail', 'v1', credentials=creds, cache_discovery=False)


def send_email(subject: str, body: str) -> tuple[bool, str]:
    try:
        msg = EmailMessage()
        msg['To'] = WILLIAM_EMAIL
        msg['Subject'] = subject
        msg.set_content(body)
        raw = base64.urlsafe_b64encode(msg.as_bytes()).decode('ascii')
        sent = gmail_service().users().messages().send(userId='me', body={'raw': raw}).execute()
        return True, f'Gmail {sent.get("id")}'
    except Exception as exc:
        return False, f'{type(exc).__name__}: {str(exc)[:300]}'


def alert(message: str, subject: str, force_email: bool = False) -> None:
    local_ok, local_detail = send_local_messages(message)
    if local_ok:
        log(f'alert primary: {local_detail}')
        return
    max_ok, max_detail = (False, 'forced email') if force_email else send_max(message)
    log(f'alert local: {local_detail}; secondary: {max_detail}')
    if not max_ok or force_email:
        _, email_detail = send_email(subject, message + f'\n\nLocal Messages path: {local_detail}\nSecondary path: {max_detail}')
        log(f'alert fallback email: {email_detail}')


def should_alert(check: dict[str, Any]) -> bool:
    return check.get('severity') == 'urgent'


def main() -> int:
    if not acquire_lock():
        log('another urgent-monitor run appears active; skipping')
        return 0
    try:
        state = load_state()
        checks_state = state.setdefault('checks', {})
        now = dt.datetime.now().astimezone().isoformat(timespec='seconds')
        for check in CHECKS:
            check_id = check['id']
            previous = checks_state.get(check_id, {'state': 'unknown'})
            previous_state = previous.get('state', 'unknown')
            ok, details = verified_probe(check)
            current_state = 'ok' if ok else 'down'
            checks_state[check_id] = {
                'state': current_state,
                'last_checked': now,
                'name': check['name'],
                'target': check['target'],
                'severity': check['severity'],
                'details': details[-3:],
            }
            log(f"{check_id} {current_state}: {' | '.join(details)}")

            if current_state == 'down':
                if previous_state in {'ok', 'unknown'}:
                    checks_state[check_id]['state'] = 'suspect_down'
                    checks_state[check_id]['suspect_since'] = now
                    log(f'{check_id} suspect_down: waiting for next cycle before alerting')
                    continue
                if previous_state == 'suspect_down' and should_alert(check):
                    checks_state[check_id]['state'] = 'down'
                    checks_state[check_id]['down_since'] = previous.get('suspect_since', now)
                    subject = f"URGENT: {check['name']} is DOWN"
                    message = (
                        f"URGENT: {check['name']} is DOWN after repeated verification.\n\n"
                        f"Target: {check['target']}\n"
                        f"Severity: {check['severity']}\n"
                        f"Why it matters: {check['why']}\n"
                        f"Verification: {' | '.join(details)}\n"
                        f"First suspect: {previous.get('suspect_since', now)}\n"
                        f"Time: {now}"
                    )
                    alert(message, subject, force_email=check_id.startswith('SAL_'))
                elif previous_state == 'suspect_down':
                    log(f'{check_id} still suspect_down but severity is not urgent; no page')
            elif current_state == 'ok' and previous_state == 'down':
                subject = f"RECOVERY: {check['name']} is back UP"
                message = f"RECOVERY: {check['name']} is back UP.\n\nTarget: {check['target']}\nVerification: {' | '.join(details)}\nTime: {now}"
                if should_alert(check):
                    alert(message, subject)
            elif current_state == 'ok' and previous_state == 'suspect_down':
                checks_state[check_id]['state'] = 'ok'
                checks_state[check_id].pop('suspect_since', None)
                log(f'{check_id} recovered before alert threshold')
        save_state(state)
        return 0
    finally:
        release_lock()


if __name__ == '__main__':
    raise SystemExit(main())
