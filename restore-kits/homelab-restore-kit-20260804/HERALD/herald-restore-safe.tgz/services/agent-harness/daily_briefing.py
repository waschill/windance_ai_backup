#!/usr/bin/env python3
import json
import time
import urllib.request


HARNESS = "http://127.0.0.1:8791"
NODE_RED_SEND = "http://192.168.36.22:1880/codex/send-imessage"
DEFAULT_PHONE = "+16054401255"


def post_json(url, payload, timeout=180):
    req = urllib.request.Request(
        url,
        data=json.dumps(payload).encode(),
        headers={"Content-Type": "application/json"},
    )
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.load(r)


def post_json_retry(url, payload, timeout=30, attempts=8, delay=60):
    last_error = None
    for attempt in range(1, attempts + 1):
        try:
            return post_json(url, payload, timeout=timeout)
        except Exception as exc:
            last_error = exc
            print(f"delivery attempt {attempt}/{attempts} failed for {url}: {exc}", flush=True)
            if attempt < attempts:
                time.sleep(delay)
    raise last_error


def main():
    briefing = post_json(f"{HARNESS}/briefing", {"days": 2, "email_limit": 12}, timeout=240)
    text = "Max daily briefing:\n\n" + (briefing.get("reply") or "No briefing text returned.")
    if len(text) > 3500:
        text = text[:3475].rstrip() + "..."
    post_json_retry(NODE_RED_SEND, {"to": DEFAULT_PHONE, "message": text}, timeout=30)
    print("daily briefing delivered", flush=True)


if __name__ == "__main__":
    main()
