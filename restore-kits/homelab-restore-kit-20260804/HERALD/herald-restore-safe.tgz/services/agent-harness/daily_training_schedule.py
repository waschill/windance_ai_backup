#!/usr/bin/env python3
import json
import time
import datetime as dt
import urllib.request


HARNESS = "http://127.0.0.1:8791"
NODE_RED_SEND = "http://192.168.36.22:1880/codex/send-imessage"
SHAWN_PHONE = "+16054403400"


def get_json(url, timeout=120):
    with urllib.request.urlopen(url, timeout=timeout) as r:
        return json.load(r)


def post_json(url, payload, timeout=30):
    req = urllib.request.Request(
        url,
        data=json.dumps(payload).encode(),
        headers={"Content-Type": "application/json"},
    )
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.load(r)


def post_json_retry(url, payload, timeout=30, attempts=6, delay=45):
    last_error = None
    for attempt in range(1, attempts + 1):
        try:
            return post_json(url, payload, timeout=timeout)
        except Exception as exc:
            last_error = exc
            print(f"delivery attempt {attempt}/{attempts} failed for {url}: {exc}", flush=True)
            if attempt < attempts:
                time.sleep(delay)
    raise last_error


def save_schedule_memory(text):
    today = dt.datetime.now().astimezone().date()
    key = today.strftime("%Y_%m_%d")
    value = (
        f"Windance daily training schedule report for {today.isoformat()}.\n\n"
        f"{text}\n\n"
        "This is a historical snapshot saved when the daily report ran. "
        "Use this record for later questions about what the training schedule was on this date, "
        "rather than re-reading the current Odoo work schedule."
    )
    return post_json(
        f"{HARNESS}/memory",
        {
            "kind": "daily_training_schedule",
            "key": key,
            "value": value,
            "confidence": 0.96,
            "source": "daily_training_schedule.py",
        },
        timeout=60,
    )


def main():
    schedule = get_json(f"{HARNESS}/training/today", timeout=180)
    text = schedule.get("reply") or "No training schedule text returned."
    try:
        save_schedule_memory(text)
        print("daily training schedule saved to dated memory", flush=True)
    except Exception as exc:
        print(f"memory save failed; continuing with Shawn delivery: {exc}", flush=True)
    message = "Windance daily training report:\n\n" + text
    if len(message) > 3500:
        message = message[:3475].rstrip() + "..."
    post_json_retry(NODE_RED_SEND, {"to": SHAWN_PHONE, "message": message}, timeout=30)
    print("daily training schedule delivered to Shawn", flush=True)


if __name__ == "__main__":
    main()
