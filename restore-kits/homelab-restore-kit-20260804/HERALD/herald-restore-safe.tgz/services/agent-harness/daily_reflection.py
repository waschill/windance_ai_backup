#!/usr/bin/env python3
import json
import re
import urllib.request


HARNESS = "http://127.0.0.1:8791"


def post_json(url, payload, timeout=300):
    req = urllib.request.Request(
        url,
        data=json.dumps(payload).encode(),
        headers={"Content-Type": "application/json"},
    )
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.load(r)


def main():
    result = post_json(f"{HARNESS}/reflection/daily", {"hours": 24}, timeout=300)
    summary = result.get("reply") or result.get("reflection") or "No reflection text returned."
    match = re.search(r"saved it as ([A-Za-z0-9_/-]+)", summary)
    memory_key = result.get("memory_key") or (match.group(1) if match else "(no memory key returned)")
    print(f"daily reflection saved: {memory_key}", flush=True)
    print(summary[:4000], flush=True)


if __name__ == "__main__":
    main()
